package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.EmailId;

import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;



@RestController
@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)




public class MailController {
	
	String str = generateCaptcha();
	String code=str;
	String value=str;
	
	
	String str1= new String();
	public String generateCaptcha()
	 {
	  Random random = new Random();
	  int length = 5;
	  StringBuffer captchaStringBuffer = new StringBuffer();
	  for (int i = 0; i < length; i++) 
	{
	   int captchaNumber = Math.abs(random.nextInt()) % 60;
	   int charNumber = 0;
	   if (captchaNumber < 26)
	 {
	    charNumber = 65 + captchaNumber;
	   }
	   else if (captchaNumber < 52)
	{
	    charNumber = 97 + (captchaNumber - 26);
	   }
	   else 
	{
	    charNumber = 48 + (captchaNumber - 52);
	   }
	   captchaStringBuffer.append((char)charNumber);
	  }
	
	  return captchaStringBuffer.toString();
	 } 
	
	
//String str = generateCaptcha();
//String code=str;
//String value=str;	
	@Autowired 
	public JavaMailSender javaMailSender;
	
	@RequestMapping(value="/mail")
	public  String[] getcode(){
		
		return new String[] {code};
	}
	@PostMapping("/sendmail")
	public void sendMail(@RequestBody EmailId email)
	{
		
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(email.getEmail());
		message.setSubject("Stock Market verfication");
		message.setText("hello user your verification code :- "+code);
		javaMailSender.send(message);
		
		
	}
	
}	
	
	
	
	
	
	
	


