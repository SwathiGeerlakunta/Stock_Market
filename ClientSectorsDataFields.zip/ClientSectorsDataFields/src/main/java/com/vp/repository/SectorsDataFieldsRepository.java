package com.vp.repository;

import org.springframework.data.repository.CrudRepository;

import com.vp.model.SectorsDataFields;

public interface SectorsDataFieldsRepository extends CrudRepository<SectorsDataFields, Long>{

}
