package com.vp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.vp.model.SectorsDataFields;
import com.vp.service.SectorsDataFieldsService;

@RestController
public class SectorsDataFieldsController {
	
	@Autowired
	SectorsDataFieldsService sectorsDataFieldsService;
	
	@GetMapping("/sectorsDataFields")
	public List<SectorsDataFields> getSectorsDataFields(){
		return sectorsDataFieldsService.getAllSectorsDataFields();
	}
	
	@PostMapping("/sectorsDataField")
	public void insertSectorsDataFields(@RequestBody SectorsDataFields sectorsDataFields) {
		sectorsDataFieldsService.saveSectorsDataFields(sectorsDataFields);
	}
	
}