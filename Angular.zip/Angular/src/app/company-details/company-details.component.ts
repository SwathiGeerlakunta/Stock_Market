import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { CompanyDetailsModel } from 'src/app/company-details/CompanyDetailsModel';
import { CompanyDetailsService } from 'src/app/company-details/company-details.service';

@Component({
  selector: 'app-company-details',
  templateUrl: './company-details.component.html',
  styleUrls: ['./company-details.component.css']
})
export class CompanyDetailsComponent implements OnInit {

  constructor(private router: Router,private service:CompanyDetailsService) { }
  myForm4: FormGroup;
  companyDetails:CompanyDetailsModel[];
  company:CompanyDetailsModel;

  ngOnInit(): void {
    this.service.getAllCompanyDetails().subscribe(data => {
      this.companyDetails = data.body;
      console.log(data.body)
 });
    {
      this.myForm4 = new FormGroup({
        name: new FormControl(''),
        
      });
  }
}
  onSubmit4(form: FormGroup){
  }
  submit2(company){
     window.localStorage.setItem('item2',JSON.stringify(company));
     this.router.navigate(['/app-company-update']);
  }
  title = 'SPB-Test3';
}

