import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router'

@Component({
  selector: 'app-compare-company',
  templateUrl: './compare-company.component.html',
  styleUrls: ['./compare-company.component.css']
})
export class CompareCompanyComponent implements OnInit {

  testform: FormGroup;

  constructor(private router: Router) { }

  ngOnInit(): void {

    this.testform = new FormGroup({
      first: new FormControl(''),
      second: new FormControl('')
    });
  }

  Submit(form: FormGroup){
    var cmp1='cts';
    var cmp2='tcs';
    var cmp3='wipro';
    var cmp4='infosys';
    if((cmp1==form.value.first && cmp2==form.value.second) || (cmp2==form.value.first && cmp1==form.value.second)){
      this.router.navigate(['/bar-chart']);
    }

    if((cmp1==form.value.first && cmp3==form.value.second) || (cmp3==form.value.first && cmp1==form.value.second)){
      this.router.navigate(['/bar-chart1']);
    }

    if((cmp1==form.value.first && cmp4==form.value.second) || (cmp4==form.value.first && cmp1==form.value.second)){
      this.router.navigate(['/bar-chart4']);
    }

    if((cmp2==form.value.first && cmp3==form.value.second) || (cmp3==form.value.first && cmp2==form.value.second)){
      this.router.navigate(['/bar-chart2']);
    }

    if((cmp2==form.value.first && cmp4==form.value.second) || (cmp4==form.value.first && cmp2==form.value.second)){
      this.router.navigate(['/bar-chart3']);
    }

    if((cmp4==form.value.first && cmp3==form.value.second) || (cmp3==form.value.first && cmp4==form.value.second)){
      this.router.navigate(['/bar-chart5']);
    }

    if((cmp1==form.value.first && cmp1==form.value.second)){
     alert('Please Select Different Companies');
    }

    if((cmp2==form.value.first && cmp2==form.value.second)){
      alert('Please Select Different Companies');
    }

    if((cmp3==form.value.first && cmp3==form.value.second)){
      alert('Please Select Different Companies');
    }

    if((cmp4==form.value.first && cmp4==form.value.second)){
      alert('Please Select Different Companies');
    }
  }

}
