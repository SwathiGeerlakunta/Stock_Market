import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-land',
  templateUrl: './admin-land.component.html',
  styleUrls: ['./admin-land.component.css']
})
export class AdminLandComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
