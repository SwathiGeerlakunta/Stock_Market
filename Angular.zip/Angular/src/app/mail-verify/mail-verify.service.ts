import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MailVerifyModel } from './MailVerifyModel';
import { MailVerifyModel2 } from '../mail-verify/MailVerifyModel2';

type EntityResponseType = HttpResponse<MailVerifyModel[]>;

@Injectable({
  providedIn: 'root'
})
export class MailVerifyService {

  constructor(private http:HttpClient) { }

  getCode():Observable<EntityResponseType>{
        return this.http.get<MailVerifyModel[]>("http://localhost:5517/mail", {observe: 'response'});
  }

  saveEmail(mailVerifyModel:MailVerifyModel2){
       return this.http.post<MailVerifyModel2>("http://localhost:5517/sendmail", mailVerifyModel, {observe: 'response'});
  }
  

}