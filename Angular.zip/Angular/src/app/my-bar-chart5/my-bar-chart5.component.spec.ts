import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyBarChart5Component } from './my-bar-chart5.component';

describe('MyBarChart5Component', () => {
  let component: MyBarChart5Component;
  let fixture: ComponentFixture<MyBarChart5Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyBarChart5Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyBarChart5Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
