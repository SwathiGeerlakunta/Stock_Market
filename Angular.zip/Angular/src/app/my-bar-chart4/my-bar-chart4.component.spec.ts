import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyBarChart4Component } from './my-bar-chart4.component';

describe('MyBarChart4Component', () => {
  let component: MyBarChart4Component;
  let fixture: ComponentFixture<MyBarChart4Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyBarChart4Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyBarChart4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
