export interface ExcelInfoModel{
    toDate:Date;
    fromDate:Date;
    noOfRecord:number;
    stockExchange:string
}