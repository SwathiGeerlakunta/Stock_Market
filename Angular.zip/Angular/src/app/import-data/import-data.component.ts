import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ExcelModel } from 'src/app/import-data/ExcelModel';
import { ImportExcelService } from 'src/app/import-data/import-excel.service';
import { HttpResponse } from '@angular/common/http';
import { ExcelInfoModel } from './ExcelInfoModel';

@Component({
  selector: 'app-import-data',
  templateUrl: './import-data.component.html',
  styleUrls: ['./import-data.component.css']
})
export class ImportDataComponent implements OnInit {
  currentFileUpload: File;
  selectedFiles: FileList;
  excelDetails:ExcelModel[];
  excelinfo:ExcelInfoModel[];

  constructor(private service:ImportExcelService,private router: Router) { }
  selectFile(event) {
    this.selectedFiles = event.target.files;
  }
 


  ngOnInit(): void {
    this.service.getAllDetails().subscribe(data => {
    this.excelDetails = data.body;
    console.log(data.body) 
});

  }
  
  // alert("done");
    //this.router.navigate(['/app-company-create']);
    upload() {
      this.currentFileUpload = this.selectedFiles.item(0);
      this.service.pushFileToStorage(this.currentFileUpload).subscribe(event => {
       if (event instanceof HttpResponse) {
          alert('File is completely uploaded!');
        }
        
      });
     
      this.service.getAllinfo().subscribe(data => {
        this.excelinfo = data.body;
        console.log(data.body) 
    });
    console.log(this.excelinfo);
      this.selectedFiles = undefined;
    }

}
