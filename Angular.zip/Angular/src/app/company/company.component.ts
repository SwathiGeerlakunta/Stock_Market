import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {

  testform: FormGroup;

  constructor(private router: Router) { }

  ngOnInit(): void {
    this.testform = new FormGroup({
      first: new FormControl('')
    });
  }

  Submit(form: FormGroup){
    var cmp1='cts';
    var cmp2='tcs';
    var cmp3='wipro';
    var cmp4='infosys';
    if(cmp1==form.value.first){
      this.router.navigate(['/chart1']);
    }

    if((cmp2==form.value.first)){
      this.router.navigate(['/chart2']);
    }

    if((cmp3==form.value.first)){
      this.router.navigate(['/chart3']);
    }

    if((cmp4==form.value.first)){
      this.router.navigate(['/chart4']);
    }
  }

}
