import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AdminLandComponent } from './admin-land/admin-land.component';
import { LandingComponent } from './landing/landing.component';
import {RouterModule,Routes} from "@angular/router";
import { CreatecompanyComponent } from './createcompany/createcompany.component';
import { UserLandComponent } from './user-land/user-land.component';
import {LoginService} from 'src/app/login/login.service';
import { UsersService } from 'src/app/service/users.service';
import { ImportDataComponent } from './import-data/import-data.component';
import { UpdateIpoService } from 'src/app/update-ipo/update-ipo.service';
import { CompanyDetailsService } from 'src/app/company-details/company-details.service';
import { ManageExchangeService } from 'src/app/manage-exchange/manage-exchange.service';
import { ImportExcelService } from 'src/app/import-data/import-excel.service';

import { MailVerifyService } from 'src/app/mail-verify/mail-verify.service';
import { MailVerifyComponent } from './mail-verify/mail-verify.component';
import { CompanyDetailsComponent } from './company-details/company-details.component';
import { UpdateIpoComponent } from './update-ipo/update-ipo.component';
import { CompanyUpdateComponent } from './company-update/company-update.component';
import { ManageExchangeComponent } from './manage-exchange/manage-exchange.component';
import { IpoDetailsComponent } from './ipo-details/ipo-details.component';
import { BarChartComponent } from './bar-chart/bar-chart.component';
import { BarChart1Component } from './bar-chart1/bar-chart1.component';
import { BarChart2Component } from './bar-chart2/bar-chart2.component';
import { BarChart3Component } from './bar-chart3/bar-chart3.component';
import { CompanyComponent } from './company/company.component';
import { CompareCompanyComponent } from './compare-company/compare-company.component';
import { CompareSectorComponent } from './compare-sector/compare-sector.component';
import { MyBarChartComponent } from './my-bar-chart/my-bar-chart.component';
import { MyBarChart1Component } from './my-bar-chart1/my-bar-chart1.component';
import { MyBarChart2Component } from './my-bar-chart2/my-bar-chart2.component';
import { MyBarChart3Component } from './my-bar-chart3/my-bar-chart3.component';
import { MyBarChart4Component } from './my-bar-chart4/my-bar-chart4.component';
import { MyBarChart5Component } from './my-bar-chart5/my-bar-chart5.component';
import { ChartsModule } from 'ng2-charts';


const routes:Routes = [ // added new
  {path:'', redirectTo:'landing', pathMatch:'full'},
  {path:'landing', component:LandingComponent},
  {path:'login', component:LoginComponent},
  {path:'register', component:RegisterComponent},
  {path:'adminland', component:AdminLandComponent },
  {path:'createcomp', component:CreatecompanyComponent },
  {path:'userland', component:UserLandComponent },
   {path:'app-mail-verify', component:MailVerifyComponent },
   {path:'list', component:CompanyDetailsComponent },
   {path:'app-company-update', component:CompanyUpdateComponent },
   {path:'manage-exchange', component:ManageExchangeComponent },
   {path:'update-ipo', component:UpdateIpoComponent },
   {path:'ipo-details', component:IpoDetailsComponent },
   {path:'import', component:ImportDataComponent },
   {path: 'bar-chart', component: MyBarChartComponent},
   {path: 'bar-chart1', component: MyBarChart1Component} ,
   {path: 'bar-chart2', component: MyBarChart2Component},
   {path: 'bar-chart3', component: MyBarChart3Component} ,
   {path: 'bar-chart4', component: MyBarChart4Component},
   {path: 'bar-chart5', component: MyBarChart5Component},
   {path: 'chart1', component: BarChartComponent} ,
   {path: 'chart2', component: BarChart1Component},
   {path: 'chart3', component: BarChart2Component} ,
   {path: 'chart4', component: BarChart3Component},
   {path: 'company', component: CompanyComponent},
   {path: 'compare-company', component: CompareCompanyComponent} ,
   {path: 'compare-sector', component: CompareSectorComponent}
 ];



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    AdminLandComponent,
    LandingComponent,
    CreatecompanyComponent,
    UserLandComponent,
    ImportDataComponent,
    MailVerifyComponent,
    CompanyDetailsComponent,
    UpdateIpoComponent,
    CompanyUpdateComponent,
    ManageExchangeComponent,
    IpoDetailsComponent,
    BarChartComponent,
    BarChart1Component,
    BarChart2Component,
    BarChart3Component,
    CompanyComponent,
    CompareCompanyComponent,
    CompareSectorComponent,
    MyBarChartComponent,
    MyBarChart1Component,
    MyBarChart2Component,
    MyBarChart3Component,
    MyBarChart4Component,
    MyBarChart5Component

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule,
    ChartsModule,
    RouterModule.forRoot(routes)
  ],
  exports: [],
  providers: [LoginService, UsersService, ImportExcelService, ManageExchangeService,  MailVerifyService, UpdateIpoService, CompanyDetailsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
