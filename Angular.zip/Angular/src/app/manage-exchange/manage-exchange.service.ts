import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ManageExchangeModel } from './ManageExchangeModel';

type EntityResponseType = HttpResponse<ManageExchangeModel[]>;

@Injectable({
  providedIn: 'root'
})
export class ManageExchangeService {

  constructor(private http:HttpClient) { }

  getAllExchange():Observable<EntityResponseType>{
        return this.http.get<ManageExchangeModel[]>("http://localhost:5516/stockExchangeDataFields", {observe: 'response'});
  }

  saveExchange(manageExchangeModel:ManageExchangeModel){
    return this.http.post<ManageExchangeModel>("http://localhost:5516/stockExchangeDataField", manageExchangeModel, {observe: 'response'});
}

}