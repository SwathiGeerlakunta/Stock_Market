import { Component, OnInit } from '@angular/core';
import { RouterModule, Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import {loginModel} from 'src/app/login/loginModel';
import { RegisterService } from 'src/app/register/register.service';
import { MailVerifyService } from 'src/app/mail-verify/mail-verify.service';


import { MailVerifyModel } from '../mail-verify/MailVerifyModel';
import { MailVerifyModel2 } from '../mail-verify/MailVerifyModel2';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  myForm2: FormGroup;
  userDetails2:loginModel[];
  sendEmail:MailVerifyModel2[];

  constructor(private service:RegisterService,private router: Router,private service2:MailVerifyService) { }
  
  ngOnInit(): void {
          this.myForm2 = new FormGroup({
        name: new FormControl(''),
        mob: new FormControl(''),
        eid: new FormControl(''),
        pwd: new FormControl('')
        
      });

      this.service.getAllUserDetails().subscribe(data => {
        this.userDetails2 = data.body;
        console.log(data.body) 
   });

      

      }
      onSubmit2(form: FormGroup){
        var x = (form.value.name+form.value.pwd);
        let userDetails2:loginModel = {
          id:x,
          username:form.value.name,
          password:form.value.pwd,
          usertype:'user',
          email:form.value.eid,
          mobile_number:form.value.mob,
          confirmation:'confirmed'
        }

        let sendEmail2:MailVerifyModel2={
          email:form.value.eid
        }

        window.localStorage.setItem('item4',JSON.stringify(userDetails2));
        
        console.log("sending mail");
         this.service2.saveEmail(sendEmail2).subscribe(data =>{
           console.log(data.body);
           console.log("mail sent!!");
        });

        this.router.navigate(['/app-mail-verify']);
      }
  title = 'SPB-Test3';
}

