import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bar-chart2',
  templateUrl: './bar-chart2.component.html',
  styleUrls: ['./bar-chart2.component.css']
})
export class BarChart2Component implements OnInit {

  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true
  };

  public barChartLabels = ['2013', '2014', '2015', '2016', '2017', '2018', '2019'];
  public barChartType = 'bar';
  public barChartLegend = true;

  public barChartData = [
    {data: [55, 48, 72, 88, 48, 58, 50], label: 'WIPRO'}
  ];

  constructor() { }

  ngOnInit() {
  }

}
