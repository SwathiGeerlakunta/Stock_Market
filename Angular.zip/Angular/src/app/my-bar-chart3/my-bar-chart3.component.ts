import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-bar-chart3',
  templateUrl: './my-bar-chart3.component.html',
  styleUrls: ['./my-bar-chart3.component.css']
})
export class MyBarChart3Component implements OnInit {

  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true
  };

  public barChartLabels = ['2013', '2014', '2015', '2016', '2017', '2018', '2019'];
  public barChartType = 'bar';
  public barChartLegend = true;

  public barChartData = [
    {data: [83, 59, 80, 81, 56, 55, 40], label: 'TCS'},
    {data: [65, 58, 62, 88, 88, 58, 80], label: 'INFOSYS'}
  ];

  constructor() { }

  ngOnInit() {
  }

}
