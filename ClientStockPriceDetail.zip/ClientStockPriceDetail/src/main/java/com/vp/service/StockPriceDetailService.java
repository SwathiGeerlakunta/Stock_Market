package com.vp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vp.model.StockPriceDetail;
import com.vp.repository.StockPriceDetailRepository;

@Service
@Transactional
public class StockPriceDetailService {
	@Autowired
	StockPriceDetailRepository stockPriceDetailRepository;
	
	public void saveStockPriceDetail(StockPriceDetail stockPriceDetail) {
		stockPriceDetailRepository.save(stockPriceDetail);
	}
	
	public List<StockPriceDetail> getAllStockPriceDetail(){
		return (List<StockPriceDetail>) stockPriceDetailRepository.findAll();
	}
}